# Modals

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `buttons.md`, `inputs.md`

## Core Specs

### Overlay (Backdrop)
- Fixed, covers full screen
- Z-index: 40
- Background: black at 50% opacity
- Backdrop blur: small amount

### Content Container
- Background: neutral-primary
- Radius: 8px (base)
- Shadow: shadow-lg
- Padding: 16px

## Anatomy

### Header
- Bottom border: border-default
- Top corners rounded (8px)
- Title: 18px, semibold weight, heading color
- Close button: Ghost variant from `buttons.md`, 6px padding

### Body
- Vertical padding: 16px
- Vertical spacing between elements: 16px
- Text: 14px, 1.6 line-height, body color

### Footer
- Top border: border-default
- Bottom corners rounded (8px)

## Variants

### Default (Information)
Standard header + body + footer with primary/secondary action buttons.

### Pop-up (Confirmation)
Centered text, prominent icon, reduced padding:
- Body: 16px padding, text centered
- Icon: centered, 12px bottom margin, 40x40px, gray color

### Form Modal
Body contains inputs following `inputs.md`. Vertical spacing between form elements: 12px.

## Rules

- Backdrop covers full screen with fixed positioning
- Content: neutral-primary background, 8px radius, shadow-lg
- Header/Footer separated by border-default borders
- Close button must be present and functional
- Accessibility: `role="dialog"`, implement focus trap in code
- Dark mode automatic via token system
